"use client";
import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Import cohort components
import CohortA from "../../components/Cohorts/CohortA";
import CohortB from "../../components/Cohorts/CohortB";
import CohortC from "../../components/Cohorts/CohortC";

const Dashboard = () => {
  const [cohort, setCohort] = useState("");
  const router = useRouter();

  useEffect(() => {
    const fetchContent = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        router.push("/"); // Redirect to login if no token
        return;
      }

      const response = await fetch("http://localhost:5000/dashboard", {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await response.json();
      if (response.ok) {
        setCohort(data.cohort); // Set the cohort from the backend response
      } else {
        console.error("Failed to fetch content");
        router.push("/"); // Redirect to login if token is invalid
      }
    };

    fetchContent();
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("token"); // Remove the token
    toast.success("Logged out successfully! Redirecting..."); // Success toast
    setTimeout(() => {
      router.push("/"); // Redirect to login page
    }, 2000); // Delay for toast to show
  };

  // Render the appropriate cohort component
  const renderCohortContent = () => {
    switch (cohort) {
      case "Cohort A":
        return <CohortA />;
      case "Cohort B":
        return <CohortB />;
      case "Cohort C":
        return <CohortC />;
      default:
        return <p>Loading...</p>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Dashboard</h1>
        {renderCohortContent()} {/* Render cohort-specific content */}
        <button
          onClick={handleLogout}
          className="w-full cursor-pointer bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 transition duration-200"
        >
          Logout
        </button>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
};

export default Dashboard;