"use client";
import React, { useState, useEffect } from "react";
import { FaUser, FaEye, FaEyeSlash } from "react-icons/fa";
import { TbLockPassword } from "react-icons/tb";
import { MdAlternateEmail } from "react-icons/md";
import { useRouter } from "next/navigation";
import Turnstile from "react-turnstile";
import CustomInput from "./Reusables/CustomInput";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [errors, setErrors] = useState({});
  const router = useRouter();

  const backgroundImage = {
    backgroundImage:
      "url(https://images.pexels.com/photos/6594387/pexels-photo-6594387.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    height: "100vh",
    width: "100vw",
    position: "relative",
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      router.push("/dashboard"); // Redirect to dashboard if already logged in
    }
  }, [router]);

  const validateForm = () => {
    const newErrors = {};
    if (!email) {
      newErrors.email = "Email is required";
      toast.warning("Email is required");
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Email address is invalid";
      toast.error("Email address is invalid");
    }
    if (!password) {
      newErrors.password = "Password is required";
      toast.warning("Password is required");
    }
    if (!captchaToken) {
      newErrors.captcha = "CAPTCHA verification is required";
      toast.error("CAPTCHA verification is required");
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);

    try {
      const response = await fetch("http://localhost:5000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("token", data.token); // Store token
        toast.success("Login successful! Redirecting..."); // Success toast
        setTimeout(() => {
          router.push("/dashboard"); // Redirect to dashboard
        }, 2000); // Delay for toast to show
      } else {
        setErrors({ backend: data.message || "Login failed" });
        toast.error(data.message || "Login failed"); // Error toast
      }
    } catch (error) {
      setErrors({ backend: "Server error. Please try again later." });
      toast.error("Server error. Please try again later."); // Error toast
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <div
        style={backgroundImage}
        className="flex justify-center px-2 items-center h-screen"
      >
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "rgba(0, 0, 0, 0.2)",
          }}
        ></div>

        <div className="w-[65svh] py-8 h-auto rounded-[40px] bg-white/60 backdrop-blur-3xl relative z-10">
          <div className="flex lg:px-8 px-4 flex-col justify-center items-center">
            <img
              src="https://www.vrt9.net/research/vrtlogo.png"
              className="w-32 h-16"
              alt="Logo"
            />
            <h1 className="mt-10 gsans text-[#0c0c0c] text-2xl lg:text-3xl font-bold">
              Sign in to your account
            </h1>
            <p className="small text-center lg:text-lg text-[#484848] mt-4">
              This page is only available to people who have{" "}
              <br className="hidden lg:block" /> been given access.
            </p>

            <form onSubmit={handleSubmit} className="w-full">
              <CustomInput
                className="border mt-10 placeholder:text-black w-full dark:bg-[#0c0c0c] border-zinc-400 dark:border-zinc-800 rounded-3xl"
                icon={MdAlternateEmail}
                type="text"
                name="email"
                label="Enter your email"
                onChange={(e) => setEmail(e.target.value)}
                value={email}
                error={errors.email}
              />
              <div className="relative">
                <CustomInput
                  className="border mt-5 placeholder:text-black w-full dark:bg-[#0c0c0c] border-zinc-400 dark:border-zinc-800 rounded-3xl"
                  icon={TbLockPassword}
                  type={showPassword ? "text" : "password"}
                  name="password"
                  label="Enter your password"
                  onChange={(e) => setPassword(e.target.value)}
                  value={password}
                  error={errors.password}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute cursor-pointer right-3 top-1/2 transform -translate-y-1/2"
                >
                  {showPassword ? (
                    <img
                      src="https://www.svgrepo.com/show/361151/eye-closed.svg"
                      className="w-5 h-5"
                      alt="Logo"
                    />
                  ) : (
                    <img
                      src="https://www.svgrepo.com/show/361149/eye.svg"
                      className="w-5 h-5"
                      alt="Logo"
                    />
                  )}
                </button>
              </div>

              <Turnstile
                className="mt-5"
                sitekey="0x4AAAAAABBIRlrytMYf90D5"
                onVerify={setCaptchaToken}
              />
              {/* {errors.captcha && (
                <p className="text-red-500 text-sm mt-2">{errors.captcha}</p>
              )} */}
              {/* {errors.backend && (
                <p className="text-red-500 text-sm mt-2">{errors.backend}</p>
              )} */}
              <button
                type="submit"
                disabled={isLoading}
                className="lg:w-full cursor-pointer w-full small mt-5 order-last flex justify-center items-center gap-3 text-lg px-12 bg-[#ff0000] text-white p-4 rounded-3xl"
              >
                {isLoading ? (
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                ) : (
                  <>
                    Sign in
                    <img src="/signin.svg" className="w-6 h-6" alt="Logo" />
                  </>
                )}
              </button>
              <p className="small text-center px-4 lg:text-lg text-[#484848] mt-4">
                Having trouble? Contact the admin.
              </p>
            </form>
          </div>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
};

export default Login;
