import React from 'react'

const CohortC = () => {
  return (
    <div>
     COHORT C 
    </div>
  )
}

export default CohortC
