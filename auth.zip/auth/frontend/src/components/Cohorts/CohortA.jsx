import React from 'react'

const CohortA = () => {
  return (
    <div>
      COHORT A
    </div>
  )
}

export default CohortA
