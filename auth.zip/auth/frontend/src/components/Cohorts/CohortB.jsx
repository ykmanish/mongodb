import React from 'react'

const CohortB = () => {
  return (
    <div>
      COHORT B
    </div>
  )
}

export default CohortB
